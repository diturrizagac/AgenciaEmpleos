
import vista.JfrmPortadaP;



public class Programa {
    public static void main(String[] args){
        //Creamos la ventana de inicio de sesión.
        JfrmPortadaP portada = new JfrmPortadaP();
        
    }
    
}
